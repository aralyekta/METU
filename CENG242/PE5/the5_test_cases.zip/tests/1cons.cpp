#include <iostream>
#include "../path_tracker.h"

int main()
{
    PathTracker pt = PathTracker();
    pt.summary();

    return 0;
}