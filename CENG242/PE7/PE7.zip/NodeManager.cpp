
#include "NodeManager.h"

NodeManager::NodeManager() {
	// TODO
}

NodeManager::~NodeManager() {
	// TODO
}

void NodeManager::addRelation(int parent, int child) {
	// TODO
}

void NodeManager::setDataToNode(int id, char data) {
	// TODO
}

const Node& NodeManager::getNode(int id) {
	// TODO
}