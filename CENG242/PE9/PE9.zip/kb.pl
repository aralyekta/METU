% CHANGES DONE TO THIS FILE WILL BE OVERWRITTEN. 
% IT WILL HAVE NO EFFECT ON YOUR GRADE.

:- module(kb, [person/3, word/1]).

% person(Name, Age, Hobby)
person(joseph, 27, reading).
person(jessica, 32, crafting).
person(michael, 22, reading).
person(william, 33, reading).
person(elizabeth, 30, television).
person(jennifer, 38, crafting).
person(patricia, 33, bird_watching).
person(charles, 39, bird_watching).
person(david, 31, bird_watching).
person(mary, 25, crafting).
person(barbara, 25, reading).
person(richard, 32, travelling).
person(james, 22, fishing).
person(susan, 32, reading).
person(karen, 40, bird_watching).
person(sarah, 25, crafting).
person(linda, 21, reading).
person(john, 28, reading).
person(thomas, 23, bird_watching).
person(robert, 22, television).

% word(Atom)
word(acaba).
word(adana).
word(alaca).
word(araba).
word(eleme).
word(fiili).
word(ikili).
word(kekik).
word(ninni).
word(sosis).
word(afacan).
word(ajanda).
word(akbaba).
word(akraba).
word(ananas).
word(badana).
word(binici).
word(birisi).
word(deneme).
word(derece).
word(duyuru).
word(ezbere).
word(ikinci).
word(kabaca).
word(kamara).
word(kasaba).
word(keklik).
word(lahana).
word(matbaa).
word(muamma).
word(nerede).
word(otonom).
word(salata).
word(sessiz).
word(tabaka).
word(uyumlu).
word(yarasa).
word(yasama).
word(abla).
word(ada).
word(ala).
word(ama).
word(arka).
word(ayak).
word(baba).
word(daha).
word(dede).
word(dere).
word(deve).
word(evet).
word(gece).
word(imam).
word(inci).
word(kek).
word(kutu).
word(kuyu).
word(kuzu).
word(masa).
word(maya).
word(ses).
word(sis).
word(tat).
word(tava).
word(ufuk).
word(ulu).
word(uyku).
word(vana).
