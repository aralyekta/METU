#include <iostream>
#include "person.h"

using namespace std;

Person::Person(const string &name, float balance, int age)
{
}

void Person::print_info()
{
}