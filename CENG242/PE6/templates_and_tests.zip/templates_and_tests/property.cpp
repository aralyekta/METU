#include <iostream>
#include "property.h"
#include "owner.h"

using namespace std;

Property::Property()
{
}

Property::Property(const string &property_name, int area, Owner *owner)
{
}

void Property::set_owner(Owner *owner)
{
}

float Property::valuate()
{
}

string &Property::get_name()
{
}

void Property::print_info()
{
}